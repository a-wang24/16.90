function L = Lfun(Un)
%Lift Function
% 
global Q

a = Un(1);

L = Q*a;

end

